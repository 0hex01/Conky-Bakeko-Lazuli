#!/bin/bash

# Exit on error
set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to find conky_lazuli directory
find_conky_lazuli_dir() {
    # Try relative to script first
    local script_dir="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
    local possible_dirs=(
        "$script_dir/../conky_lazuli"
        "$script_dir/conky_lazuli"
        "$(pwd)/conky_lazuli"
        "/tmp/conky_lazuli"
        "$HOME/conky_lazuli"
        "/opt/conky_lazuli"
    )

    for dir in "${possible_dirs[@]}"; do
        if [ -d "$dir" ] && [ -f "$dir/conky.conf" ]; then
            echo "$(realpath "$dir")"
            return 0
        fi
    done
    
    # If not found, try to find it anywhere in the system
    local found_dir=$(find / -type d -name "conky_lazuli" -exec test -f "{}/conky.conf" \; -print -quit 2>/dev/null || true)
    if [ -n "$found_dir" ]; then
        echo "$found_dir"
        return 0
    fi
    
    return 1
}

# Find the conky_lazuli directory
PACKAGE_DIR=$(find_conky_lazuli_dir)
if [ -z "$PACKAGE_DIR" ]; then
    echo -e "${RED}[ERROR]${NC} Could not find conky_lazuli directory. Please ensure the package is extracted properly."
    exit 1
fi

echo -e "${GREEN}[*]${NC} Found Conky Lazuli files in: $PACKAGE_DIR"

# Function to print status messages
print_status() {
    echo -e "${GREEN}[*]${NC} $1"
}

# Function to print warnings
print_warning() {
    echo -e "${YELLOW}[!]${NC} $1"
}

# Function to print errors and exit
print_error() {
    echo -e "${RED}[ERROR]${NC} $1"
    exit 1
}

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    print_error "This script must be run as root. Use 'sudo $0'"
fi

# Function to detect package manager
detect_pkg_manager() {
    if command -v apt-get &> /dev/null; then
        echo "apt"
    elif command -v dnf &> /dev/null; then
        echo "dnf"
    elif command -v yum &> /dev/null; then
        echo "yum"
    elif command -v pacman &> /dev/null; then
        echo "pacman"
    else
        print_error "Could not detect package manager. Please install conky and lm-sensors manually."
    fi
}

# Install required packages
install_dependencies() {
    local pkg_manager=$(detect_pkg_manager)
    
    print_status "Using package manager: $pkg_manager"
    
    case $pkg_manager in
        apt)
            apt-get update
            apt-get install -y conky-all lm-sensors
            if apt-cache show hddtemp &>/dev/null; then
                apt-get install -y hddtemp
            else
                print_warning "hddtemp not available in repositories, skipping..."
            fi
            ;;
        dnf|yum)
            $pkg_manager install -y conky lm_sensors
            ;;
        pacman)
            pacman -Syu --noconfirm conky lm_sensors
            ;;
    esac
}

# Main installation function
install_conky_lazuli() {
    local target_user=$1
    local user_home="/home/$target_user"
    
    if [ "$target_user" = "root" ]; then
        user_home="/root"
    fi
    
    # Check if user exists
    if ! id "$target_user" &>/dev/null; then
        print_error "User $target_user does not exist!"
    fi
    
    print_status "Installing Conky Lazuli for user: $target_user"
    
    # Create config directory
    local config_dir="$user_home/.config/conky"
    mkdir -p "$config_dir"
    
    # Create target directory structure
    print_status "Creating directory structure in $config_dir..."
    mkdir -p "$config_dir"
    
    # Copy all files except installer
    print_status "Copying configuration files..."
    (cd "$PACKAGE_DIR" && find . -type f ! -path "*/\.*" ! -path "*/installer/*" -print0 | \
    while IFS= read -r -d $'\0' file; do
        target_file="$config_dir/${file#./}"
        target_dir="$(dirname "$target_file")"
        
        # Create target directory if it doesn't exist
        mkdir -p "$target_dir"
        
        # Copy file with proper permissions
        if [[ "$file" == *.sh ]] || [[ "$file" == *.py ]]; then
            install -m 755 "$PACKAGE_DIR/$file" "$target_file"
        else
            install -m 644 "$PACKAGE_DIR/$file" "$target_file"
        fi
        
        echo "  - Installed: $target_file"
    done)
    
    # Set special permissions for specific files if they exist
    [ -f "$config_dir/power_monitor.sh" ] && chmod +x "$config_dir/power_monitor.sh"
    
    # Set up autostart
    print_status "Setting up autostart..."
    local autostart_dir="$user_home/.config/autostart"
    mkdir -p "$autostart_dir"
    
    cat > "$autostart_dir/conky-lazuli.desktop" <<EOL
[Desktop Entry]
Type=Application
Name=Conky Lazuli
Exec=conky -c $config_dir/conky.conf
Comment=Conky system monitor with Bakeneko Lazuli theme
X-GNOME-Autostart-enabled=true
X-MATE-Autostart-enabled=true
EOL
    
    # Set permissions
    chown -R "$target_user:$target_user" "$user_home/.config/conky"
    chown "$target_user:$target_user" "$autostart_dir/conky-lazuli.desktop"
    chmod +x "$autostart_dir/conky-lazuli.desktop"
    
    print_status "Installation complete for user: $target_user"
}

# Show usage
show_usage() {
    echo "Usage: $0 [username]"
    echo "If no username is provided, the current user will be used."
    exit 1
}

# Main script
print_status "=== Conky Lazuli Installation ==="

# Get target user
TARGET_USER="${1:-$SUDO_USER}"
if [ -z "$TARGET_USER" ]; then
    TARGET_USER="$(whoami)"
fi

# Install dependencies
print_status "Installing required dependencies..."
install_dependencies

# Install for the target user
install_conky_lazuli "$TARGET_USER"

print_status "================================"
echo -e "${GREEN}Conky Lazuli has been successfully installed!${NC}"
echo "- Configuration directory: ~/.config/conky/"
echo "- Autostart file: ~/.config/autostart/conky-lazuli.desktop"
echo "\nYou can start Conky Lazuli manually with:"
echo "  conky -c ~/.config/conky/conky.conf"
echo "\nIt will start automatically on your next login."

exit 0
