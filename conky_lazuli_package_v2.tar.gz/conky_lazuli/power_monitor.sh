#!/bin/bash

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root (to access RAPL counters)" >&2
    exit 1
fi

# Check if RAPL is available
if [ ! -d "/sys/class/powercap/intel-rapl" ]; then
    echo "RAPL not available on this system" >&2
    exit 1
fi

# Get the first RAPL zone (usually package-0)
RAPL_ZONE=$(ls -d /sys/class/powercap/intel-rapl/intel-rapl:*/ | head -n 1)

if [ -z "$RAPL_ZONE" ]; then
    echo "No RAPL zone found" >&2
    exit 1
fi

# Get the energy counter file
ENERGY_FILE="${RAPL_ZONE}energy_uj"
MAX_ENERGY_FILE="${RAPL_ZONE}max_energy_range_uj"

# Get the energy unit (joules per tick)
ENERGY_UNIT=1e-6  # microjoules to joules

# Get initial energy and time
prev_energy=$(< "$ENERGY_FILE")
prev_time=$(date +%s%N)

# Main loop
while true; do
    # Sleep for approximately 1/30th of a second (33.33ms)
    sleep 0.03333
    
    # Get current energy and time
    curr_energy=$(< "$ENERGY_FILE")
    curr_time=$(date +%s%N)
    
    # Calculate time difference in seconds
    time_diff=$(awk -v t1=$prev_time -v t2=$curr_time 'BEGIN {print (t2 - t1) / 1000000000}')
    
    # Calculate energy difference in joules and power in watts
    if [ $curr_energy -lt $prev_energy ]; then
        # Counter wrapped around, get max energy and add the difference
        max_energy=$(< "$MAX_ENERGY_FILE")
        energy_diff=$(awk -v max=$max_energy -v prev=$prev_energy -v curr=$curr_energy -v unit=$ENERGY_UNIT 'BEGIN {print (max - prev + curr) * unit}')
    else
        energy_diff=$(awk -v curr=$curr_energy -v prev=$prev_energy -v unit=$ENERGY_UNIT 'BEGIN {print (curr - prev) * unit}')
    fi
    
    power=$(awk -v e=$energy_diff -v t=$time_diff 'BEGIN {print e / t}')
    
    # Output the power in watts to a file for Conky
    printf "%.2f" "$power" > /tmp/power_usage
    
    # Update previous values
    prev_energy=$curr_energy
    prev_time=$curr_time
done
