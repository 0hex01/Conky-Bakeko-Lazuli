# Conky Lazuli Theme

A beautiful and functional Conky theme for Debian-based systems.

## Features

- Modern, clean interface
- System monitoring (CPU, RAM, disk, network, etc.)
- Autostart configuration
- Easy installation

## Installation

1. Extract the package:
   ```bash
   tar -xzf conky_lazuli_package.tar.gz
   cd conky_lazuli_package
   ```

2. Run the installer as root:
   ```bash
   sudo ./installer/install.sh [username]
   ```
   - If no username is provided, it will install for the current user
   - For system-wide installation, use `sudo ./installer/install.sh root`

3. Conky Lazuli will start automatically on your next login.

## Manual Start

To start Conky Lazuli manually:
```bash
conky -c ~/.config/conky/confy.conf
```

## Customization

Edit the configuration file at `~/.config/conky/conky.conf` to customize the theme.

## Requirements

- Conky
- lm-sensors (for temperature monitoring)
- A compositing window manager (for transparency)

## License

This project is open source and available under the MIT License.

## Screenshot

![Conky Lazuli Preview](conky_lazuli/lazuli-preview.jpg)
